# Failure Forensics Tool for AI Pipelines

## Overview
An observability layer for multi-step AI pipelines that traces every intermediate step. It identifies exactly where failures originate when the final output is bad and feeds flagged failures back into a growing evaluation dataset.

## Why This Project Exists
When a complex AI pipeline produces bad results, most teams have no idea which step broke. This project solves that by providing full tracing and observability, showcasing senior-level engineering skills.

See **[SYSTEM_DESIGN.md](./SYSTEM_DESIGN.md)** for the full architecture, data flow, and what each file needs to do — that's the actual spec to build against.

## Pipeline Architecture
1. **Ingestion** — Parses raw text and simulated documents.
2. **Extraction** — Uses an LLM to pull structured entities.
3. **Classification** — Categorizes the document based on context.
4. **Generation** — Creates a tailored response.

## Tech Stack
| Component | Tool / Library |
|---|---|
| Language | Python 3.11+ |
| Pipeline Framework | Custom Python orchestration |
| LLM Provider | OpenAI API |
| Tracing | OpenTelemetry |
| Storage | SQLite + JSON trace files |
| Visualization | Streamlit |
| Feedback Loop | FastAPI REST API |
| Containerization | Docker |

## Project Structure
```
failure-forensics-tool/
├── SYSTEM_DESIGN.md       # architecture spec — start here
├── src/
│   ├── models.py           # TODO: Span, PipelineTrace dataclasses
│   ├── tracer.py            # TODO: Tracer class — span context manager + persistence
│   ├── pipeline.py           # TODO: the 4-step pipeline wired to the tracer
│   └── feedback_api.py        # TODO: FastAPI endpoints for traces + flagging
├── dashboard/
│   └── app.py                  # TODO: Streamlit trace viewer
├── tests/
│   └── test_pipeline.py         # TODO: tests for span tracing + failure flagging
├── traces/                        # SQLite db + JSON trace files land here at runtime
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── .env.example
```

## Setup Instructions
1. Clone the repository
2. Copy `.env.example` to `.env` and add your OpenAI API key
3. Build out each file in `src/` following `SYSTEM_DESIGN.md`, in the build order at the bottom of that doc
4. Once `pipeline.py` runs standalone, build the Docker setup: `docker compose up --build`
5. Streamlit dashboard: `http://localhost:8501` · Feedback API: `http://localhost:8000`

## Roadmap
- [ ] Phase 1: `models.py` — data shapes
- [ ] Phase 2: `tracer.py` — span capture + SQLite/JSON persistence
- [ ] Phase 3: `pipeline.py` — 4-step pipeline wired to the tracer
- [ ] Phase 4: `tests/test_pipeline.py`
- [ ] Phase 5: `feedback_api.py`
- [ ] Phase 6: `dashboard/app.py`
- [ ] Phase 7 (later): integrate tracing into the SA Grocery Price Intelligence Platform Airflow DAG instead of this demo pipeline
