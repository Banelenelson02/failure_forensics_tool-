"""Data models for pipeline traces and spans.

See SYSTEM_DESIGN.md, section 3, for the full spec:
- Span dataclass (step_name, trace_id, span_id, input_summary, output_summary,
  status, error, started_at, ended_at, duration_ms)
- SpanStatus enum (OK, FAILED, FLAGGED)
- PipelineTrace dataclass (trace_id, spans, final_status, created_at)
- PipelineTrace.first_failed_step() — returns the earliest failed/flagged span

TODO: implement Span, SpanStatus, PipelineTrace here.
"""
