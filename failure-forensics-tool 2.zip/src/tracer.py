"""Wraps pipeline steps in spans, persists traces to SQLite + JSON files.

See SYSTEM_DESIGN.md, section 4, for the full spec:
- init_db() — creates traces/traces.db with `traces` and `spans` tables
- Tracer class — holds one PipelineTrace per run
- Tracer.step(step_name, input_summary) — context manager: creates a Span,
  times it, catches exceptions -> FAILED, empty output -> FLAGGED, appends
  to the trace. Wrap the underlying work in an OpenTelemetry span too.
- Tracer.save() — computes final_status, writes traces/{trace_id}.json,
  and inserts rows into SQLite

TODO: implement init_db() and the Tracer class here.
"""
