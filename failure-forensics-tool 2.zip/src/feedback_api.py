"""REST API for browsing traces and flagging failures into an eval dataset.

See SYSTEM_DESIGN.md, section 6, for the full spec:
- GET  /traces               — list traces from SQLite, optional ?status= filter
- GET  /traces/{trace_id}    — full JSON detail for one trace
- POST /traces/{trace_id}/flag — mark a trace flagged_for_eval=True

TODO: implement the FastAPI app and these three endpoints here.
"""
