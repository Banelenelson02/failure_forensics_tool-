"""4-step pipeline: ingestion -> extraction -> classification -> generation.

See SYSTEM_DESIGN.md, section 5, for the full spec:
- ingest(text, tracer), extract(document, tracer), classify(entities, tracer),
  generate(category, tracer) — each wraps its work in tracer.step(...) and
  sets span.output_summary before returning
- run_pipeline(text) -> (output, trace) — creates one Tracer, runs all 4
  steps in order, calls tracer.save() even if a step raises

Stub the extraction/generation logic (no real OpenAI calls) until the
tracing layer is proven to work, then swap in real LLM calls.

TODO: implement ingest, extract, classify, generate, run_pipeline here.
"""
