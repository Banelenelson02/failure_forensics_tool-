"""Tests for the pipeline + tracer.

See SYSTEM_DESIGN.md, section 8:
- test_pipeline_runs_and_traces_all_steps — a normal run produces 4 spans,
  in the right order
- test_empty_input_is_flagged_not_silently_passed — bad input surfaces as
  a FAILED or FLAGGED span, not a silently "successful" run

TODO: write these tests, then implement the pipeline against them.
"""
