# System Design — Failure Forensics Tool

This doc is the blueprint. Nothing here is implemented for you — it's what
each file in `src/` needs to do and how they talk to each other. Build it
in the phase order below.

## 1. What the system does

Runs a multi-step pipeline, wraps every step in a "span" (a record of
what went in, what came out, whether it worked), and persists those spans
so that when the final output is bad, you can look at the trace and see
exactly which step broke — instead of guessing.

## 2. Data flow

```
input text
   │
   ▼
[ingestion]  ──span──▶
   │
   ▼
[extraction] ──span──▶
   │
   ▼
[classification] ──span──▶
   │
   ▼
[generation] ──span──▶
   │
   ▼
final output + PipelineTrace (all 4 spans, one per step)
   │
   ├──▶ SQLite (for querying: "show me all failed traces")
   └──▶ JSON file per trace (for full detail: exact inputs/outputs of every step)
```

## 3. Core data models — `src/models.py`

Two dataclasses. This is the contract everything else is built on, so get
this right first.

**`Span`** — one traced step:
- `step_name: str`
- `trace_id: str` — links it back to its parent trace
- `span_id: str` — unique per span
- `input_summary: str` / `output_summary: str` — short human-readable strings, not full payloads
- `status: SpanStatus` — enum: `OK`, `FAILED` (raised an exception), `FLAGGED` (ran fine but output looks suspicious — e.g. empty)
- `error: str | None`
- `started_at`, `ended_at`, `duration_ms`

**`PipelineTrace`** — one full run:
- `trace_id`, `spans: list[Span]`, `final_status`, `created_at`
- Needs a method `first_failed_step()` — walks `spans` in order and returns the first one with `FAILED` or `FLAGGED` status. This is the actual "forensics" — root cause, not just "something broke."

**Design question to think through yourself:** should `final_status` be
worse-of-all-spans, or last-span-only? (Hint: worse-of-all — a mid-pipeline
failure that still produces *some* final output shouldn't read as "OK".)

## 4. Tracer — `src/tracer.py`

This is the piece that makes tracing automatic instead of something you
manually log at every step.

- A `Tracer` class, one instance per pipeline run, holding a `PipelineTrace`.
- A context manager method `step(step_name, input_summary)` that:
  - creates a `Span`, times it
  - yields the span so the calling code can set `span.output_summary`
  - catches exceptions → sets status `FAILED`, records the error, re-raises
  - if it completes with no output set → mark `FLAGGED` (silent-failure detection)
  - appends the finished span to the trace
- A `save()` method that writes the trace to SQLite (one row per trace,
  one row per span, for fast querying) **and** a full JSON file
  (`traces/{trace_id}.json`) with complete span detail.
- Wrap each `step()` call in an OpenTelemetry span too (`opentelemetry-sdk`)
  so this could plug into a real observability backend later — that's the
  "senior signal" part of the exercise, so it's worth actually learning,
  not stubbing out.

## 5. Pipeline — `src/pipeline.py`

The 4 steps from the README. Each one:
1. Takes the previous step's output
2. Does its (currently stub / later real LLM) work inside `tracer.step(...)`
3. Sets `span.output_summary` before returning

Steps:
- `ingest(text, tracer)` — parse/clean raw input
- `extract(document, tracer)` — pull structured entities (stub now, LLM call later)
- `classify(entities, tracer)` — categorize based on extracted entities
- `generate(category, tracer)` — produce the final response

`run_pipeline(text)` ties them together, creates one `Tracer`, calls
`tracer.save()` at the end (even on failure — that's the point), returns
`(output, trace)`.

**Think about:** what happens if `extract()` raises halfway through? Does
`generate()` still run? (No — and your test suite should prove that.)

## 6. Feedback API — `src/feedback_api.py`

FastAPI app, three endpoints:
- `GET /traces` — list traces from SQLite, optional `?status=failed` filter
- `GET /traces/{trace_id}` — full JSON detail for one trace
- `POST /traces/{trace_id}/flag` — mark a trace as belonging in the growing eval dataset (add a `flagged_for_eval` field to its JSON)

This is the "feeds flagged failures back into a growing evaluation
dataset" part of the brief — the flagged traces are your future eval set.

## 7. Dashboard — `dashboard/app.py`

Streamlit. Read from SQLite + the JSON files, list traces color-coded by
status, expand one to see each span's input/output/error/duration.

## 8. Testing — `tests/test_pipeline.py`

At minimum, prove:
- a normal run produces all 4 spans in order
- a bad input (e.g. empty string) gets flagged somewhere, not silently passed through

## 9. Later: integrating into Grocery Price Intelligence

Once this works standalone, the real payoff is wrapping the Airflow DAG
(scrape → clean → load → geocode → recommend) in the same `Tracer`
instead of the toy 4-step pipeline — same models, same tracer, real data.
Don't build this yet; get the standalone version solid first.

## Build order (recommended)

1. `models.py` — get the data shapes right, write a tiny script to create and print a `Span` by hand
2. `tracer.py` — build `step()` and `save()`, test by wrapping a fake function that sometimes throws
3. `pipeline.py` — wire the 4 stub steps together, run it, check `traces/` fills up
4. `tests/test_pipeline.py` — lock in the behavior before you touch the API/dashboard
5. `feedback_api.py`
6. `dashboard/app.py`
