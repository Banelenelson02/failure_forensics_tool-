"""Streamlit dashboard for browsing pipeline traces.

See SYSTEM_DESIGN.md, section 7, for the full spec:
- Read traces from SQLite + traces/{trace_id}.json
- List traces, color-coded by status (ok/flagged/failed)
- Expand a trace to see each span's step_name, status, duration, error,
  input_summary, output_summary

TODO: implement the Streamlit dashboard here.
"""
